﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SwaggerDemo.DBContext;
using SwaggerDemo.IdentityAuth;
using System.Linq;
using System.Threading.Tasks;

namespace SwaggerDemo.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;
        public ProductsController(IConfiguration configuration, ApplicationDbContext context)
        {
            _configuration = configuration;
            _context = context;
        }

        [HttpGet]
        [Route("GetList")]
        public IActionResult GetList()
        {
            var products = _context.Products.ToList();
            return Ok(new Response { Status = "Success", Message = "User created successfully!", Data = products });
        }
    }
}
