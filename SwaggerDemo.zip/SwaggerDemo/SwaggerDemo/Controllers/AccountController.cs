﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;
using SwaggerDemo.IdentityAuth;
using SwaggerDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwaggerDemo.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IConfiguration _configuration;
        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IConfiguration configuration)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            var url = _configuration["JWT:Issuer"] + "/api/Authenticate/login";
            var client = new RestClient(url);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", "Basic TWFsZVVzZXI6MTIzNDU2");
            request.AddHeader("Content-Type", "application/json");
            var body = @"{" + "\n" +
                @"  ""userName"": """ + model.UserName + "\"," + "\n" +
                @"  ""password"": """ + model.Password + "\"" + "\n" +
                @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            LoginResponse data = JsonConvert.DeserializeObject<LoginResponse>(response.Content);

            if (data.twofactorenable)
                return RedirectToAction("TwoFactorLogin");

            return RedirectToAction("LoggedIn");
        }

        [HttpGet]
        public IActionResult LoggedIn()
        {
            return View();
        }
    }
}
