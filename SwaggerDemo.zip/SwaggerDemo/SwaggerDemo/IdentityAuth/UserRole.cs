﻿namespace SwaggerDemo.IdentityAuth
{
    public static class UserRoles
    {
        public static string Admin { get; set; } = "Admin";
        public static string User { get; set; } = "User";
    }
}
