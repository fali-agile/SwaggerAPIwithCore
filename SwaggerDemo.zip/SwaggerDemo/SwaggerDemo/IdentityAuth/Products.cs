﻿using System.ComponentModel.DataAnnotations;

namespace SwaggerDemo.IdentityAuth
{
    public class Products
    {
        [Key]
        public int Id { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
